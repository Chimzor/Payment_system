# Fashion MNIST CNN Classification In Python/R

This project uses the Fashion MNIST dataset to categorize images using an implementation of a Convolutional Neural Network (CNN) using Keras.

## Requirements

- Python 3.x  
- R 4.0+  
- RStudio  
- TensorFlow 2.16.2  
- Keras package 2.15.0  
- NumPy  
- Matplotlib  

Install the required Python packages if not available with: (cmd)  
```bash
pip install tensorflow keras matplotlib numpy
```

Install the required R packages in RStudio:  
```r
install.packages("keras")
library(keras)
library(tensorflow)
install_keras()
install_tensorflow()
```

---

## How to Run the Python Script

- Unzip the project folder  
- Navigate to the project directory  
- Run the Python script  
```bash
python FMN.py
```

---

## How to Run the R Script

- Unzip the project folder  
- Navigate to the project directory  
- Run the R script in RStudio or from the command line  
```bash
Rscript FMN_R.R
```

---

## To View the README File

- Navigate to the project directory  
- Open the **README.md** file to view  

---

## Project Structure

- `FMN.py` → Python implementation of Fashion MNIST CNN  
- `FMN_R.R` → R implementation of Fashion MNIST CNN  
- `FMN.ipynb` → Jupyter Notebook with step-by-step explanation  
- `README.md` → Documentation file  

Both **FMN.py**, **FMN_R.R**, **FMN.ipynb**, and **README.md** are zipped in the folder **"Assignment_FashionMNIST_Class_M6_zip"** and uploaded to the GitHub repository:

 **GitHub Link:** [https://github.com/Chimzor/Payment_system](https://github.com/Chimzor/Payment_system)

# PCA and Logistic Regression of the Breast Cancer Dataset

This project demonstrates how to use the Breast Cancer dataset from `sklearn.datasets` for **Principal Component Analysis (PCA)** to identify essential variables. It also includes an **optional logistic regression model** to predict cancer classes after dimensionality reduction.

## Requirements
- Python 3.x
- NumPy
- Pandas
- Matplotlib
- scikit-learn

To install the required packages using pip (in Command Prompt):

```bash
pip install numpy pandas scikit-learn matplotlib

How to Run the code
- Unzip the project folder
- Navigate to the project directory
- Run the Python script

'''bash

python Mil2_PCA.py

The script will output:
- A visualization of the PCA results (saved as 'pca_visualization.png')
- (Optional) Accuracy and classification report for the logistic regression model


To view the README file
- Navigate to the project directory
- Open the "Mil2_README.md" file to view

# Project Structure
| File Name               | Description                                               |
| ----------------------- | --------------------------------------------------------- |
| `Mil2_PCA.py`           | Main Python script performing PCA and logistic regression |
| `pca_visualization.png` | Output image of the PCA scatter plot                      |
| `Mil2_README.md`        | Instructions and project documentation                    |
| `Mil2_PCA_zip/`         | Zipped folder containing all files                        |

# GitHub Repository
Both Mil2_PCA.py and Mil2_README.md are zipped inside the folder named "Mil2_PCA_zip" and uploaded to the GitHub repository linked below:

https://github.com/Chimzor/Payment_system



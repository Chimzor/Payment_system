import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import zipfile
import os

%matplotlib inline

# Task 1: Import Data
df = pd.read_csv('C:/Users/User/Mod2_SalaryFunction_zip/Salaray Data/Total.csv', low_memory=False)

# Display dataset basic data
df.info()
df.head()

print('This Dataset contains {} Rows and {} Columns'.format(df.shape[0], df.shape[1]))

# Convert columns to float64
series_list = ['BasePay', 'OvertimePay', 'OtherPay', 'Benefits']
for series in series_list:
    df[series] = pd.to_numeric(df[series], errors='coerce')

# Confirm columns conversion and display descriptive data
df.info()
df[['BasePay', 'TotalPay', 'Benefits', 'OvertimePay', 'OtherPay', 'TotalPayBenefits']].describe()

# Number of unique years in the dataset
A = df['Year'].nunique()
B = df['Year'].unique()
print('The information of {} years are available in the dataset:{}'.format(A, B))

# Visualizations of TotalPay and BasePay
sns.kdeplot(df['TotalPay'], fill=True)
sns.kdeplot(df['BasePay'], fill=True)

# Barplot of yearly TotalPay
sns.barplot(data=df, x='Year', y='TotalPay')

# Number of yearly unique job titles
df.groupby('Year').nunique()['JobTitle']

# Display yearly unique job titles
print(df.groupby('Year').nunique()['JobTitle'])

# Task 2: Create Employee Function
def get_employee_details(name):
    try:
        employee = df[df['EmployeeName'].str.lower() == name.lower()]
        if employee.empty:
            return "Employee not found in the dataset."
        else:
            return employee
    except Exception as e:
        return f"Error occurred: {e}"

# Usage case
print(get_employee_details('Jude Okonkwo'))

# Task 3: Data Processing with Dictionary
# Convert dataframe to dictionary
salary_dict = df.to_dict(orient='records')

# Usage case of processing the dictionary
processed_data = {}
for employee in salary_dict:
    # Add any additional processing here
    name = employee['EmployeeName']
    processed_data[name] = {
        'BasePay': employee['BasePay'],
        'TotalPay': employee['TotalPay'],
        'Benefits': employee['Benefits'],
        'OvertimePay': employee['OvertimePay'],
        'OtherPay': employee['OtherPay']
    }
    
# Task 4: Error Handling
def secure_get_employee_details(name):
    try:
        employee = df[df['EmployeeName'].str.lower() == name.lower()]
        if employee.empty:
            return "Employee not found in the dataset."
        else:
            return employee
    except Exception as e:
        return f"Error occurred: {e}"

# Usage case with error handling
print(secure_employee_details('Nnamdi Eze'))

# Task 5: Export Employee Details to CSV and Zip
def export_employee_details(name, output_dir='.'):
    employee = get_employee_details(name)
    if isinstance(employee, pd.DataFrame):
        # Ensure the output directory exists
        os.makedirs(output_dir, exist_ok=True)
        
        # Create the CSV filename
        filename = f"{name.replace(' ', '_')}_details.csv"
        filepath = os.path.join(output_dir, filename)
        
        # Export employee details to CSV
        employee.to_csv(filepath, index=False)
        
        # Create the zip file
        zip_filepath = os.path.join(output_dir, 'Employee_Profile.zip')
        with zipfile.ZipFile(zip_filepath, 'w') as zipf:
            zipf.write(filepath, arcname=filename)
        
        # Remove the CSV file after zipping
        os.remove(filepath)
        
        return f"{filename} exported and zipped as {zip_filepath}"
    else:
        return employee

# Usage case
print(export_employee_details('Jude Okonkwo'))

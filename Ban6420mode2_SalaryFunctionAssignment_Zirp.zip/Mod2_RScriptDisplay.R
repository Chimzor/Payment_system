
R version 4.4.0 (2024-04-24 ucrt) -- "Puppy Cup"
Copyright (C) 2024 The R Foundation for Statistical Computing
Platform: x86_64-w64-mingw32/x64

R is free software and comes with ABSOLUTELY NO WARRANTY.
You are welcome to redistribute it under certain conditions.
Type 'license()' or 'licence()' for distribution details.

  Natural language support but running in an English locale

R is a collaborative project with many contributors.
Type 'contributors()' for more information and
'citation()' on how to cite R or R packages in publications.

Type 'demo()' for some demos, 'help()' for on-line help, or
'help.start()' for an HTML browser interface to help.
Type 'q()' to quit R.

[Workspace loaded from ~/.RData]

> # Define the path to the zip file
> zip_file_path <- "Employee_Profile.zip"
> 
> # Unzip the Employee Profile folder
> unzip("Employee_Profile.zip", exdir = "Employee_Profile")
> 
> # List the files in the unzipped folder
> files <- list.files("Employee_Profile")
> print("Extracted files:")
[1] "Extracted files:"
> print(files)
[1] "Alson_Lee_details.csv"
> 
> # Read and display the content of the CSV file
> file_path <- file.path("Employee_Profile", files[1])
> employee_data <- read.csv(file_path)
> print("contents of the CSV file:")
[1] "contents of the CSV file:"
> print(employee_data)
  
> 
# Employee Salary Data Analysis

## Oveview

This project focuses on analyzing salary data for employees in San Francisco. The workflow includes importing data, creating functions to retrieve employee details, processing data using dictionaries, implementing error handling mechanisms, exporting employee information to a CSV file, and displaying the data using R.

## Files

- `Mod2_Salary_Function.ipynb`: Jupyter Notebook containing the Python code for generating and exporting employee details.
- `Mod2_RScrriptDisplay.R`: R script to unzip the folder and display data.
- `Employee_Profile.zip`: Zipped/compressed folder containing the employee details CSV file.
- `Mod2_README.md`: This documentation file.

## Usage

### Python

1. Ensure you have Python and Jupyter Notebook installed on your system.
2. Open and run the `Mod2_Salary_Function.ipynb` notebook to generate employee details and export them to a CSV file within the Employee_Profile folder.

### R

1. Ensure you have R installed on your system.
2. Run the `Mod2_RScrriptDisplay.R` script to unzip the folder and display the data. The script extracts the ZIP file and prints the contents of the employee data CSV.

## Error Handling

Robust error handling is implemented within the Python script to manage issues related to employee detail generation and data export. Users are notified of missing or invalid entries, and fallback mechanisms are included to ensure smooth execution.
